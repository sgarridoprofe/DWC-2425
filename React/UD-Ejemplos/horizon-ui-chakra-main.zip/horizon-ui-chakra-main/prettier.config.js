module.exports = {
  trailingComma: 'all',
  singleQuote: true,
};
