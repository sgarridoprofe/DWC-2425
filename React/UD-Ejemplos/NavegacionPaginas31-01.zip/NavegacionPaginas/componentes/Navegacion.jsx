import { Link } from "react-router";

export default function Navegacion() {
  return (
    <>
        <Link to="/">Home</Link>
        <Link to="/ofertas">Ofertas</Link>
        <Link to="/detalle">Detalle</Link>
    </>
  )
}
